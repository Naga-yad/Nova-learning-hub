import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { UserRole } from '../../types';
import { 
  LogOut, 
  Menu, 
  X, 
  GraduationCap, 
  LayoutDashboard, 
  Settings, 
  UserCircle,
  Video,
  Trophy,
  BookUser,
  Users,
  Calendar
} from 'lucide-react';
import { Button } from '../ui/Button';

interface DashboardLayoutProps {
  children: React.ReactNode;
  role: UserRole;
  title: string;
}

export const DashboardLayout: React.FC<DashboardLayoutProps> = ({ children, role, title }) => {
  const { logout, user } = useAuth();
  const [isSidebarOpen, setIsSidebarOpen] = React.useState(false);
  const location = useLocation();

  // Role specific theme colors
  const themeColor = role === UserRole.ADMIN ? 'bg-indigo-600' : 'bg-emerald-600';
  const themeLight = role === UserRole.ADMIN ? 'bg-indigo-50 text-indigo-700' : 'bg-emerald-50 text-emerald-700';
  const hoverStyle = 'text-slate-600 hover:bg-slate-50 hover:text-slate-900';

  const toggleSidebar = () => setIsSidebarOpen(!isSidebarOpen);

  const teacherLinks = [
    { name: 'Dashboard', href: '/teacher/dashboard', icon: LayoutDashboard },
    { name: 'Live Sessions', href: '/teacher/sessions', icon: Video },
    { name: 'Student Marks', href: '/teacher/marks', icon: Trophy },
    { name: 'Settings', href: '/teacher/settings', icon: Settings },
  ];

  const adminLinks = [
    { name: 'Dashboard', href: '/admin/dashboard', icon: LayoutDashboard },
    { name: 'Teachers', href: '/admin/teachers', icon: BookUser },
    { name: 'Students', href: '/admin/students', icon: Users },
    { name: 'Scheduler', href: '/admin/scheduler', icon: Calendar },
    { name: 'Settings', href: '/admin/settings', icon: Settings },
  ];

  const links = role === UserRole.TEACHER ? teacherLinks : adminLinks;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Top Navigation */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button 
              onClick={toggleSidebar}
              className="p-2 -ml-2 rounded-md lg:hidden hover:bg-slate-100"
            >
              {isSidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
            <div className={`p-2 rounded-lg ${themeColor} text-white`}>
              <GraduationCap className="w-6 h-6" />
            </div>
            <span className="text-xl font-bold text-slate-900 hidden sm:block">Nova Admin Portal</span>
            <div className="h-6 w-px bg-slate-200 mx-2 hidden sm:block"></div>
            <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${themeLight} uppercase tracking-wide`}>
              {role} Portal
            </span>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center gap-3">
              <div className="text-right">
                <p className="text-sm font-medium text-slate-900">{user?.name}</p>
                <p className="text-xs text-slate-500">{user?.email}</p>
              </div>
              {user?.avatarUrl ? (
                <img src={user.avatarUrl} alt="Profile" className="w-9 h-9 rounded-full object-cover border border-slate-200" />
              ) : (
                <UserCircle className="w-9 h-9 text-slate-400" />
              )}
            </div>
            <Button variant="outline" size="sm" onClick={logout} className="ml-2">
              <LogOut className="w-4 h-4 md:mr-2" />
              <span className="hidden md:inline">Sign Out</span>
            </Button>
          </div>
        </div>
      </header>

      <div className="flex flex-1 max-w-7xl mx-auto w-full">
        {/* Sidebar (Mobile + Desktop) */}
        <aside className={`
          fixed inset-y-0 left-0 z-20 w-64 bg-white border-r border-slate-200 transform transition-transform duration-200 ease-in-out lg:translate-x-0 lg:static lg:h-auto
          ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
          mt-16 lg:mt-0
        `}>
          <nav className="p-4 space-y-1">
            {links.map((link) => {
              const isActive = location.pathname === link.href;
              return (
                <Link
                  key={link.name}
                  to={link.href}
                  className={`flex items-center gap-3 px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                    isActive ? themeLight : hoverStyle
                  }`}
                  onClick={() => setIsSidebarOpen(false)}
                >
                  <link.icon className={`w-5 h-5 ${isActive ? 'text-current' : 'text-slate-400'}`} />
                  {link.name}
                </Link>
              );
            })}
          </nav>
        </aside>

        {/* Overlay for mobile sidebar */}
        {isSidebarOpen && (
          <div 
            className="fixed inset-0 bg-slate-900/20 z-10 lg:hidden"
            onClick={() => setIsSidebarOpen(false)}
          ></div>
        )}

        {/* Main Content */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto">
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-slate-900">{title}</h1>
          </div>
          {children}
        </main>
      </div>
    </div>
  );
};