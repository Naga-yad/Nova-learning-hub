import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { UserRole } from '../types';

interface ProtectedRouteProps {
  children: React.ReactNode;
  allowedRole: UserRole;
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children, allowedRole }) => {
  const { isAuthenticated, user, isLoading } = useAuth();

  // If loading, you might show a spinner here, but for now we render nothing or children
  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center bg-slate-50">Loading...</div>;
  }

  if (!isAuthenticated || !user) {
    return <Navigate to="/" replace />;
  }

  if (user.role !== allowedRole) {
    // Strict role separation: If a teacher tries to access admin, they go to Welcome (or could go to their own dashboard)
    // Requirement: "Unauthorized route access must redirect to Welcome Page"
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
};