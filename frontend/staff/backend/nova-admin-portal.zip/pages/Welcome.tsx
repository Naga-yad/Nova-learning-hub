import React from 'react';
import { useNavigate } from 'react-router-dom';
import { GraduationCap, ShieldCheck, BookOpen } from 'lucide-react';
import { Button } from '../components/ui/Button';

export const Welcome: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex flex-col items-center justify-center p-4">
      <div className="max-w-4xl w-full">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center p-4 bg-white rounded-2xl shadow-xl mb-6">
            <GraduationCap className="w-12 h-12 text-blue-600" />
          </div>
          <h1 className="text-4xl md:text-5xl font-extrabold text-slate-900 mb-4 tracking-tight">
            Welcome to Nova Admin Portal
          </h1>
          <p className="text-lg md:text-xl text-slate-600 max-w-2xl mx-auto">
            The advanced management portal for modern education. 
            Streamlining administration and empowering educators in one secure platform.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-2xl mx-auto">
          {/* Teacher Card */}
          <div className="bg-white p-8 rounded-2xl shadow-lg border border-slate-100 hover:border-emerald-200 transition-all hover:shadow-xl group">
            <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
              <BookOpen className="w-6 h-6 text-emerald-600" />
            </div>
            <h2 className="text-2xl font-bold text-slate-900 mb-2">Teacher Portal</h2>
            <p className="text-slate-500 mb-6">Access your classes, manage marks, and connect with students.</p>
            <Button 
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
              onClick={() => navigate('/teacher/login')}
            >
              Continue as Teacher
            </Button>
          </div>

          {/* Admin Card */}
          <div className="bg-white p-8 rounded-2xl shadow-lg border border-slate-100 hover:border-indigo-200 transition-all hover:shadow-xl group">
            <div className="w-12 h-12 bg-indigo-100 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
              <ShieldCheck className="w-6 h-6 text-indigo-600" />
            </div>
            <h2 className="text-2xl font-bold text-slate-900 mb-2">Admin Portal</h2>
            <p className="text-slate-500 mb-6">Manage users, schedule sessions, and oversee system data.</p>
            <Button 
              className="w-full bg-indigo-600 hover:bg-indigo-700 text-white"
              onClick={() => navigate('/admin/login')}
            >
              Continue as Admin
            </Button>
          </div>
        </div>

        <div className="mt-12 text-center text-sm text-slate-400">
          &copy; 2024 Nova Systems. Secure & Role-Based.
        </div>
      </div>
    </div>
  );
};