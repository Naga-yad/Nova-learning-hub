import React, { useState } from 'react';
import { DashboardLayout } from '../../components/layout/DashboardLayout';
import { UserRole } from '../../types';
import { Button } from '../../components/ui/Button';
import { Card } from '../../components/ui/Card';
import { Plus, Trash2, Calendar, Clock, AlertCircle } from 'lucide-react';
import { Input } from '../../components/ui/Input';

interface ScheduleItem {
  id: string;
  subject: string;
  teacher: string;
  day: string;
  startTime: string;
  endTime: string;
  room: string;
}

const INITIAL_SCHEDULE: ScheduleItem[] = [
  { id: '1', subject: 'Mathematics', teacher: 'Dr. Sarah Wilson', day: 'Monday', startTime: '09:00', endTime: '10:30', room: '101' },
  { id: '2', subject: 'Physics', teacher: 'Mr. James Miller', day: 'Monday', startTime: '11:00', endTime: '12:30', room: 'Lab A' },
  { id: '3', subject: 'History', teacher: 'Mr. Robert Brown', day: 'Tuesday', startTime: '09:00', endTime: '10:30', room: '204' },
];

export const Scheduler: React.FC = () => {
  const [schedule, setSchedule] = useState<ScheduleItem[]>(INITIAL_SCHEDULE);
  const [newClass, setNewClass] = useState({ subject: '', teacher: '', day: 'Monday', startTime: '', endTime: '', room: '' });
  const [error, setError] = useState('');

  const handleDelete = (id: string) => {
    if(window.confirm('Are you sure you want to remove this class?')) {
      setSchedule(prev => prev.filter(item => item.id !== id));
    }
  };

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Simple conflict detection
    const hasConflict = schedule.some(item => 
      item.day === newClass.day && 
      item.room === newClass.room &&
      ((newClass.startTime >= item.startTime && newClass.startTime < item.endTime) ||
       (newClass.endTime > item.startTime && newClass.endTime <= item.endTime))
    );

    if (hasConflict) {
      setError(`Conflict detected in Room ${newClass.room} on ${newClass.day}`);
      return;
    }

    const newItem: ScheduleItem = {
      id: Math.random().toString(36).substr(2, 9),
      ...newClass
    };

    setSchedule([...schedule, newItem]);
    setNewClass({ subject: '', teacher: '', day: 'Monday', startTime: '', endTime: '', room: '' });
  };

  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

  return (
    <DashboardLayout role={UserRole.ADMIN} title="Scheduler">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Add Class Form */}
        <div className="lg:col-span-1">
          <Card title="Add Class Session" icon={<Plus className="w-5 h-5" />}>
            <form onSubmit={handleAdd} className="space-y-4">
              <Input 
                label="Subject" 
                value={newClass.subject}
                onChange={e => setNewClass({...newClass, subject: e.target.value})}
                required
              />
              <Input 
                label="Teacher" 
                value={newClass.teacher}
                onChange={e => setNewClass({...newClass, teacher: e.target.value})}
                required
              />
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Day</label>
                <select 
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  value={newClass.day}
                  onChange={e => setNewClass({...newClass, day: e.target.value})}
                >
                  {days.map(d => <option key={d} value={d}>{d}</option>)}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <Input 
                  label="Start Time" 
                  type="time" 
                  value={newClass.startTime}
                  onChange={e => setNewClass({...newClass, startTime: e.target.value})}
                  required
                />
                <Input 
                  label="End Time" 
                  type="time" 
                  value={newClass.endTime}
                  onChange={e => setNewClass({...newClass, endTime: e.target.value})}
                  required
                />
              </div>
              <Input 
                label="Room Number" 
                value={newClass.room}
                onChange={e => setNewClass({...newClass, room: e.target.value})}
                required
              />

              {error && (
                <div className="p-3 bg-red-50 text-red-700 text-sm rounded-lg flex items-center gap-2">
                  <AlertCircle className="w-4 h-4" />
                  {error}
                </div>
              )}

              <Button type="submit" fullWidth className="bg-indigo-600 hover:bg-indigo-700">
                Add to Schedule
              </Button>
            </form>
          </Card>
        </div>

        {/* Schedule List */}
        <div className="lg:col-span-2 space-y-6">
          {days.map(day => {
            const daySchedule = schedule
              .filter(s => s.day === day)
              .sort((a, b) => a.startTime.localeCompare(b.startTime));

            if (daySchedule.length === 0) return null;

            return (
              <div key={day} className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                <div className="px-6 py-3 bg-slate-50 border-b border-slate-100 flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-slate-500" />
                  <h3 className="font-semibold text-slate-700">{day}</h3>
                </div>
                <div className="divide-y divide-slate-100">
                  {daySchedule.map(item => (
                    <div key={item.id} className="p-4 flex items-center justify-between hover:bg-slate-50 transition-colors group">
                      <div className="flex items-center gap-4">
                        <div className="flex flex-col items-center justify-center w-16 h-16 bg-indigo-50 rounded-lg text-indigo-700">
                          <span className="text-sm font-bold">{item.startTime}</span>
                          <span className="text-xs text-indigo-400">to</span>
                          <span className="text-xs font-medium">{item.endTime}</span>
                        </div>
                        <div>
                          <h4 className="font-semibold text-slate-900">{item.subject}</h4>
                          <p className="text-sm text-slate-500">{item.teacher} • Room {item.room}</p>
                        </div>
                      </div>
                      <button 
                        onClick={() => handleDelete(item.id)}
                        className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-full transition-colors opacity-0 group-hover:opacity-100"
                        title="Remove Class"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
          
          {schedule.length === 0 && (
             <div className="p-12 text-center text-slate-500 bg-white rounded-xl border border-dashed border-slate-300">
               <Calendar className="w-12 h-12 text-slate-300 mx-auto mb-3" />
               <p>No classes scheduled yet.</p>
             </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
};