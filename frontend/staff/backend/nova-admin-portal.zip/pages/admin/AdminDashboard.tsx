import React from 'react';
import { useNavigate } from 'react-router-dom';
import { DashboardLayout } from '../../components/layout/DashboardLayout';
import { UserRole } from '../../types';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Users, BookUser, Calendar, TrendingUp, ArrowRight } from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const navigate = useNavigate();

  return (
    <DashboardLayout role={UserRole.ADMIN} title="Administration Console">
      {/* Quick Stats Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-slate-500">Total Students</p>
            <p className="text-3xl font-bold text-slate-900">1,248</p>
          </div>
          <div className="p-3 bg-indigo-50 rounded-full text-indigo-600">
            <Users className="w-6 h-6" />
          </div>
        </div>
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-slate-500">Active Teachers</p>
            <p className="text-3xl font-bold text-slate-900">86</p>
          </div>
          <div className="p-3 bg-indigo-50 rounded-full text-indigo-600">
            <BookUser className="w-6 h-6" />
          </div>
        </div>
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-slate-500">System Status</p>
            <p className="text-lg font-bold text-emerald-600">Operational</p>
          </div>
          <div className="p-3 bg-emerald-50 rounded-full text-emerald-600">
            <TrendingUp className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Main Action Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        
        {/* Teacher Management */}
        <Card 
          title="Manage Teachers" 
          description="Faculty profiles, access control, and assignments"
          icon={<BookUser className="w-5 h-5 text-indigo-600" />}
          className="hover:border-indigo-300 cursor-pointer transition-all"
        >
          <div className="space-y-4">
            <p className="text-sm text-slate-600">
              Complete control over teacher accounts. Add new faculty, deactivate accounts, or update personal details.
            </p>
            <Button 
              variant="primary" 
              fullWidth 
              className="bg-indigo-600 hover:bg-indigo-700 justify-between group"
              onClick={() => navigate('/admin/teachers')}
            >
              Go to Teachers
              <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
            </Button>
          </div>
        </Card>

        {/* Student Management */}
        <Card 
          title="Manage Students" 
          description="Student records, enrollment, and class assignment"
          icon={<Users className="w-5 h-5 text-indigo-600" />}
          className="hover:border-indigo-300 cursor-pointer transition-all"
        >
          <div className="space-y-4">
            <p className="text-sm text-slate-600">
              Oversee the student body. Search records, update grade levels, and manage academic status.
            </p>
            <Button 
              variant="primary" 
              fullWidth 
              className="bg-indigo-600 hover:bg-indigo-700 justify-between group"
              onClick={() => navigate('/admin/students')}
            >
              Go to Students
              <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
            </Button>
          </div>
        </Card>

        {/* Scheduler */}
        <Card 
          title="Scheduler" 
          description="Class timetables and conflict management"
          icon={<Calendar className="w-5 h-5 text-indigo-600" />}
          className="hover:border-indigo-300 cursor-pointer transition-all"
        >
           <div className="space-y-4">
            <p className="text-sm text-slate-600">
              Organize the academic calendar. Assign teachers to classes and ensure no scheduling conflicts occur.
            </p>
            <Button 
              variant="primary" 
              fullWidth 
              className="bg-indigo-600 hover:bg-indigo-700 justify-between group"
              onClick={() => navigate('/admin/scheduler')}
            >
              Open Scheduler
              <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
            </Button>
          </div>
        </Card>
      </div>
    </DashboardLayout>
  );
};