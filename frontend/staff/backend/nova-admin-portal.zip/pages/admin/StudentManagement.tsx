import React, { useState } from 'react';
import { DashboardLayout } from '../../components/layout/DashboardLayout';
import { UserRole } from '../../types';
import { Button } from '../../components/ui/Button';
import { Card } from '../../components/ui/Card';
import { Search, Plus, UserCheck, UserX, GraduationCap, Pencil, BookOpen, Mail, Filter, X } from 'lucide-react';

interface Student {
  id: string;
  name: string;
  email: string;
  grade: string;
  enrollmentId: string;
  status: 'active' | 'inactive';
  enrolledCourses: number;
}

const INITIAL_STUDENTS: Student[] = [
  { id: '1', name: 'Alice Johnson', email: 'alice.j@educore.com', grade: 'Grade 10', enrollmentId: 'STU-2024-001', status: 'active', enrolledCourses: 5 },
  { id: '2', name: 'Bob Smith', email: 'bob.s@educore.com', grade: 'Grade 11', enrollmentId: 'STU-2024-002', status: 'active', enrolledCourses: 6 },
  { id: '3', name: 'Charlie Brown', email: 'charlie.b@educore.com', grade: 'Grade 9', enrollmentId: 'STU-2024-003', status: 'inactive', enrolledCourses: 0 },
  { id: '4', name: 'David Lee', email: 'david.l@educore.com', grade: 'Grade 12', enrollmentId: 'STU-2024-004', status: 'active', enrolledCourses: 4 },
  { id: '5', name: 'Eva Green', email: 'eva.g@educore.com', grade: 'Grade 10', enrollmentId: 'STU-2024-005', status: 'active', enrolledCourses: 5 },
  { id: '6', name: 'Frank White', email: 'frank.w@educore.com', grade: 'Grade 9', enrollmentId: 'STU-2024-006', status: 'active', enrolledCourses: 0 },
];

export const StudentManagement: React.FC = () => {
  const [students, setStudents] = useState<Student[]>(INITIAL_STUDENTS);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Filter States
  const [gradeFilter, setGradeFilter] = useState('All Grades');
  const [statusFilter, setStatusFilter] = useState('All Status');
  const [enrollmentFilter, setEnrollmentFilter] = useState('All Enrollments');

  // Extract unique grades for the filter dropdown
  const uniqueGrades = Array.from(new Set(INITIAL_STUDENTS.map(s => s.grade))).sort();

  const toggleStatus = (id: string) => {
    setStudents(prev => prev.map(s => 
      s.id === id ? { ...s, status: s.status === 'active' ? 'inactive' : 'active' } : s
    ));
  };

  const handleEdit = (student: Student) => {
    // Placeholder for edit functionality
    alert(`Edit profile for ${student.name}`);
  };

  const handleAssignClass = (student: Student) => {
    // Placeholder for assign class functionality
    alert(`Assign classes for ${student.name}`);
  };

  const clearFilters = () => {
    setSearchTerm('');
    setGradeFilter('All Grades');
    setStatusFilter('All Status');
    setEnrollmentFilter('All Enrollments');
  };

  const filteredStudents = students.filter(s => {
    const searchLower = searchTerm.toLowerCase();
    const matchesSearch = 
      s.name.toLowerCase().includes(searchLower) ||
      s.enrollmentId.toLowerCase().includes(searchLower) ||
      s.email.toLowerCase().includes(searchLower);
    
    const matchesGrade = gradeFilter === 'All Grades' || s.grade === gradeFilter;
    
    const matchesStatus = statusFilter === 'All Status' || 
      (statusFilter === 'Active' && s.status === 'active') ||
      (statusFilter === 'Inactive' && s.status === 'inactive');
    
    const matchesEnrollment = enrollmentFilter === 'All Enrollments' ||
      (enrollmentFilter === 'Enrolled' && s.enrolledCourses > 0) ||
      (enrollmentFilter === 'Not Enrolled' && s.enrolledCourses === 0);

    return matchesSearch && matchesGrade && matchesStatus && matchesEnrollment;
  });

  const hasActiveFilters = searchTerm !== '' || gradeFilter !== 'All Grades' || statusFilter !== 'All Status' || enrollmentFilter !== 'All Enrollments';

  return (
    <DashboardLayout role={UserRole.ADMIN} title="Student Management">
      <div className="space-y-6">
        {/* Top Controls Container */}
        <div className="flex flex-col gap-4">
          {/* Main Actions Row */}
          <div className="flex flex-col sm:flex-row justify-between gap-4">
            <div className="relative max-w-sm w-full">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-4 w-4 text-slate-400" />
              </div>
              <input
                type="text"
                placeholder="Search students..."
                className="pl-10 pr-4 py-2 w-full border border-slate-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 shadow-sm transition-all"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Button className="bg-indigo-600 hover:bg-indigo-700">
              <Plus className="w-4 h-4 mr-2" />
              Enroll Student
            </Button>
          </div>

          {/* Filters Row */}
          <div className="flex flex-wrap items-center gap-3 bg-white p-3 rounded-xl border border-slate-200 shadow-sm">
            <div className="flex items-center gap-2 text-sm font-medium text-slate-600 mr-2">
              <Filter className="w-4 h-4" />
              <span>Filters:</span>
            </div>
            
            <select 
              className="px-3 py-1.5 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-white hover:bg-slate-50 transition-colors cursor-pointer"
              value={gradeFilter}
              onChange={(e) => setGradeFilter(e.target.value)}
            >
              <option>All Grades</option>
              {uniqueGrades.map(g => (
                <option key={g} value={g}>{g}</option>
              ))}
            </select>

            <select 
              className="px-3 py-1.5 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-white hover:bg-slate-50 transition-colors cursor-pointer"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option>All Status</option>
              <option>Active</option>
              <option>Inactive</option>
            </select>

            <select 
              className="px-3 py-1.5 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-white hover:bg-slate-50 transition-colors cursor-pointer"
              value={enrollmentFilter}
              onChange={(e) => setEnrollmentFilter(e.target.value)}
            >
              <option>All Enrollments</option>
              <option>Enrolled</option>
              <option>Not Enrolled</option>
            </select>

            {hasActiveFilters && (
              <button 
                onClick={clearFilters}
                className="ml-auto flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-red-600 hover:bg-red-50 rounded-lg transition-colors"
              >
                <X className="w-4 h-4" />
                Clear
              </button>
            )}
          </div>
        </div>

        {/* Data Table */}
        <Card className="overflow-hidden border-0 shadow-lg">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-200">
              <thead className="bg-slate-50">
                <tr>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">Student Name</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">ID & Grade</th>
                  <th className="px-6 py-4 text-center text-xs font-semibold text-slate-500 uppercase tracking-wider">Classes</th>
                  <th className="px-6 py-4 text-center text-xs font-semibold text-slate-500 uppercase tracking-wider">Status</th>
                  <th className="px-6 py-4 text-right text-xs font-semibold text-slate-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-slate-200">
                {filteredStudents.map((student) => (
                  <tr key={student.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="h-10 w-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 border border-slate-200">
                          <GraduationCap className="w-5 h-5" />
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-slate-900">{student.name}</div>
                          <div className="text-xs text-slate-500 flex items-center gap-1">
                            <Mail className="w-3 h-3" /> {student.email}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-slate-900 font-mono">{student.enrollmentId}</div>
                      <div className="inline-flex mt-1 px-2 py-0.5 rounded text-xs font-medium bg-indigo-50 text-indigo-700">
                        {student.grade}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-center">
                       <span className={`text-sm font-semibold ${student.enrolledCourses > 0 ? 'text-slate-700' : 'text-slate-400'}`}>
                         {student.enrolledCourses}
                       </span>
                       <span className="text-xs text-slate-500 block">Enrolled</span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-center">
                      <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        student.status === 'active' 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-red-100 text-red-800'
                      }`}>
                        {student.status.charAt(0).toUpperCase() + student.status.slice(1)}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <div className="flex justify-end gap-2">
                        <button 
                          onClick={() => handleAssignClass(student)}
                          className="p-1.5 rounded-lg text-slate-500 hover:bg-indigo-50 hover:text-indigo-600 transition-colors"
                          title="Assign to Class"
                        >
                          <BookOpen className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => handleEdit(student)}
                          className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 hover:text-slate-900 transition-colors"
                          title="Edit Profile"
                        >
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => toggleStatus(student.id)}
                          className={`p-1.5 rounded-lg transition-colors ${
                            student.status === 'active' 
                              ? 'text-red-500 hover:bg-red-50 hover:text-red-700' 
                              : 'text-green-500 hover:bg-green-50 hover:text-green-700'
                          }`}
                          title={student.status === 'active' ? 'Deactivate' : 'Activate'}
                        >
                          {student.status === 'active' ? <UserX className="w-4 h-4" /> : <UserCheck className="w-4 h-4" />}
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {filteredStudents.length === 0 && (
            <div className="p-12 text-center text-slate-500 flex flex-col items-center">
              <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center mb-3">
                <Filter className="w-6 h-6 text-slate-400" />
              </div>
              <p className="font-medium">No students found</p>
              <p className="text-sm">Try adjusting your filters or search terms</p>
              <button 
                onClick={clearFilters}
                className="mt-4 text-indigo-600 hover:text-indigo-700 font-medium text-sm"
              >
                Clear all filters
              </button>
            </div>
          )}
        </Card>
      </div>
    </DashboardLayout>
  );
};