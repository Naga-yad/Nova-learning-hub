import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { UserRole } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { AuthLayout } from './AuthLayout';
import { Input } from '../../components/ui/Input';
import { Button } from '../../components/ui/Button';

interface SignInProps {
  role: UserRole;
}

export const SignIn: React.FC<SignInProps> = ({ role }) => {
  const navigate = useNavigate();
  const { login, isLoading } = useAuth();
  const [formData, setFormData] = useState({ username: '', password: '' });
  const [error, setError] = useState('');

  const isTeacher = role === UserRole.TEACHER;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    try {
      await login(formData, role);
      navigate(`/${role}/dashboard`);
    } catch (err) {
      setError('Invalid username or password');
    }
  };

  return (
    <AuthLayout 
      role={role} 
      title={`Sign in as ${isTeacher ? 'Teacher' : 'Admin'}`}
      subtitle={`Enter your credentials to access the ${role} portal`}
    >
      <form className="space-y-6" onSubmit={handleSubmit}>
        <Input
          label="Username"
          type="text"
          value={formData.username}
          onChange={(e) => setFormData(prev => ({ ...prev, username: e.target.value }))}
          required
          autoFocus
        />
        
        <Input
          label="Password"
          type="password"
          value={formData.password}
          onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
          required
        />

        {error && (
          <div className="text-sm text-red-600 bg-red-50 p-2 rounded border border-red-100">
            {error}
          </div>
        )}

        <Button 
          type="submit" 
          fullWidth 
          isLoading={isLoading}
          className={isTeacher ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-indigo-600 hover:bg-indigo-700'}
        >
          Sign In
        </Button>

        <div className="text-center mt-4">
          <p className="text-sm text-slate-500">
            Don't have an account?{' '}
            <Link 
              to={`/${role}/signup`} 
              className={`font-medium ${isTeacher ? 'text-emerald-600 hover:text-emerald-500' : 'text-indigo-600 hover:text-indigo-500'}`}
            >
              Sign up
            </Link>
          </p>
        </div>
      </form>
    </AuthLayout>
  );
};