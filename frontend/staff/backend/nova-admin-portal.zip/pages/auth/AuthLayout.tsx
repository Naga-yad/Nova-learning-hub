import React from 'react';
import { UserRole } from '../../types';
import { ArrowLeft, GraduationCap } from 'lucide-react';
import { Link } from 'react-router-dom';

interface AuthLayoutProps {
  children: React.ReactNode;
  role: UserRole;
  title: string;
  subtitle: string;
}

export const AuthLayout: React.FC<AuthLayoutProps> = ({ children, role, title, subtitle }) => {
  const isTeacher = role === UserRole.TEACHER;
  const accentColor = isTeacher ? 'text-emerald-600' : 'text-indigo-600';
  const bgGradient = isTeacher 
    ? 'from-emerald-50 to-teal-50' 
    : 'from-indigo-50 to-blue-50';

  return (
    <div className={`min-h-screen bg-gradient-to-br ${bgGradient} flex flex-col justify-center py-12 sm:px-6 lg:px-8`}>
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <Link to="/" className="flex items-center justify-center gap-2 mb-8 text-slate-500 hover:text-slate-700 transition-colors">
          <ArrowLeft className="w-4 h-4" />
          <span className="text-sm font-medium">Back to Welcome</span>
        </Link>
        
        <div className="text-center">
          <div className="mx-auto h-12 w-12 bg-white rounded-xl shadow-md flex items-center justify-center mb-4">
            <GraduationCap className={`w-8 h-8 ${accentColor}`} />
          </div>
          <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">
            {title}
          </h2>
          <p className="mt-2 text-sm text-slate-600">
            {subtitle}
          </p>
        </div>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow-xl shadow-slate-200/50 sm:rounded-2xl sm:px-10 border border-white/50">
          {children}
        </div>
      </div>
    </div>
  );
};