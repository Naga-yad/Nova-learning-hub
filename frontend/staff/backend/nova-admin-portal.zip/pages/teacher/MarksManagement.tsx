import React, { useState } from 'react';
import { DashboardLayout } from '../../components/layout/DashboardLayout';
import { UserRole } from '../../types';
import { Button } from '../../components/ui/Button';
import { Card } from '../../components/ui/Card';
import { Save, X, Pencil, Plus, Search, FileDown } from 'lucide-react';

// Mock Data Types
interface Assignment {
  id: string;
  name: string;
  maxScore: number;
}

interface StudentGrade {
  id: string;
  name: string;
  scores: Record<string, number>; // assignmentId -> score
}

// Initial Mock Data
const INITIAL_ASSIGNMENTS: Assignment[] = [
  { id: 'a1', name: 'Quiz 1', maxScore: 20 },
  { id: 'a2', name: 'Midterm Exam', maxScore: 100 },
  { id: 'a3', name: 'Lab Report', maxScore: 50 },
  { id: 'a4', name: 'Final Project', maxScore: 100 },
];

const INITIAL_STUDENTS: StudentGrade[] = [
  { id: 's1', name: 'Alice Johnson', scores: { a1: 18, a2: 85, a3: 45, a4: 92 } },
  { id: 's2', name: 'Bob Smith', scores: { a1: 15, a2: 78, a3: 40, a4: 88 } },
  { id: 's3', name: 'Charlie Brown', scores: { a1: 20, a2: 92, a3: 48, a4: 95 } },
  { id: 's4', name: 'Diana Ross', scores: { a1: 12, a2: 65, a3: 35, a4: 72 } },
  { id: 's5', name: 'Evan Wright', scores: { a1: 19, a2: 88, a3: 47, a4: 90 } },
];

export const MarksManagement: React.FC = () => {
  const [students, setStudents] = useState<StudentGrade[]>(INITIAL_STUDENTS);
  const [assignments, setAssignments] = useState<Assignment[]>(INITIAL_ASSIGNMENTS);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editScores, setEditScores] = useState<Record<string, number>>({});
  const [searchTerm, setSearchTerm] = useState('');

  // Helper to calculate overall percentage
  const calculateOverall = (scores: Record<string, number>) => {
    let totalMax = 0;
    let totalScore = 0;
    assignments.forEach(a => {
      totalMax += a.maxScore;
      if (scores[a.id] !== undefined) {
        totalScore += scores[a.id];
      }
    });
    return totalMax === 0 ? 0 : Math.round((totalScore / totalMax) * 100);
  };

  const handleEdit = (student: StudentGrade) => {
    setEditingId(student.id);
    setEditScores({ ...student.scores });
  };

  const handleSave = () => {
    if (!editingId) return;
    setStudents(prev => prev.map(s => 
      s.id === editingId ? { ...s, scores: editScores } : s
    ));
    setEditingId(null);
    setEditScores({});
  };

  const handleCancel = () => {
    setEditingId(null);
    setEditScores({});
  };

  const handleScoreChange = (assignmentId: string, value: string) => {
    const numValue = parseInt(value);
    if (isNaN(numValue)) return;
    setEditScores(prev => ({ ...prev, [assignmentId]: numValue }));
  };
  
  const filteredStudents = students.filter(s => 
    s.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <DashboardLayout role={UserRole.TEACHER} title="Marks Management">
      <div className="space-y-6">
        {/* Actions Bar */}
        <div className="flex flex-col sm:flex-row justify-between gap-4">
          <div className="relative max-w-sm w-full">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-4 w-4 text-slate-400" />
            </div>
            <input
              type="text"
              placeholder="Search students..."
              className="pl-10 pr-4 py-2 w-full border border-slate-300 rounded-lg focus:ring-emerald-500 focus:border-emerald-500 shadow-sm"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex gap-2">
            <Button variant="outline" className="text-slate-600">
              <FileDown className="w-4 h-4 mr-2" />
              Export CSV
            </Button>
            <Button className="bg-emerald-600 hover:bg-emerald-700">
              <Plus className="w-4 h-4 mr-2" />
              Add Assignment
            </Button>
          </div>
        </div>

        {/* Table Card */}
        <Card className="overflow-hidden border-0 shadow-lg">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-200">
              <thead className="bg-slate-50">
                <tr>
                  <th scope="col" className="px-6 py-4 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider sticky left-0 bg-slate-50">
                    Student Name
                  </th>
                  {assignments.map(a => (
                    <th key={a.id} scope="col" className="px-6 py-4 text-center text-xs font-semibold text-slate-500 uppercase tracking-wider min-w-[120px]">
                      {a.name} 
                      <div className="text-[10px] text-slate-400 font-normal mt-0.5">Max: {a.maxScore}</div>
                    </th>
                  ))}
                  <th scope="col" className="px-6 py-4 text-center text-xs font-semibold text-slate-500 uppercase tracking-wider">
                    Overall
                  </th>
                  <th scope="col" className="px-6 py-4 text-right text-xs font-semibold text-slate-500 uppercase tracking-wider sticky right-0 bg-slate-50">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-slate-200">
                {filteredStudents.map((student) => {
                  const isEditing = editingId === student.id;
                  const overall = calculateOverall(isEditing ? editScores : student.scores);
                  
                  return (
                    <tr key={student.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900 sticky left-0 bg-white group-hover:bg-slate-50">
                        {student.name}
                      </td>
                      {assignments.map(a => (
                        <td key={a.id} className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 text-center">
                          {isEditing ? (
                            <input
                              type="number"
                              min="0"
                              max={a.maxScore}
                              className="w-20 p-2 text-center border border-slate-300 rounded-md focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none"
                              value={editScores[a.id] ?? ''}
                              onChange={(e) => handleScoreChange(a.id, e.target.value)}
                            />
                          ) : (
                            <span className={`inline-block font-medium ${
                              (student.scores[a.id] || 0) < a.maxScore * 0.6 ? 'text-red-500' : 'text-slate-700'
                            }`}>
                              {student.scores[a.id] ?? '-'}
                            </span>
                          )}
                        </td>
                      ))}
                      <td className="px-6 py-4 whitespace-nowrap text-center">
                        <span className={`px-3 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          overall >= 80 ? 'bg-green-100 text-green-800' :
                          overall >= 60 ? 'bg-yellow-100 text-yellow-800' :
                          'bg-red-100 text-red-800'
                        }`}>
                          {overall}%
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium sticky right-0 bg-white group-hover:bg-slate-50">
                        {isEditing ? (
                          <div className="flex justify-end space-x-2">
                            <button 
                              onClick={handleSave} 
                              className="p-1 rounded-full text-emerald-600 hover:bg-emerald-50 transition-colors"
                              title="Save"
                            >
                              <Save className="w-5 h-5" />
                            </button>
                            <button 
                              onClick={handleCancel} 
                              className="p-1 rounded-full text-red-600 hover:bg-red-50 transition-colors"
                              title="Cancel"
                            >
                              <X className="w-5 h-5" />
                            </button>
                          </div>
                        ) : (
                          <button 
                            onClick={() => handleEdit(student)} 
                            className="p-1 rounded-full text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 transition-colors"
                            title="Edit Grades"
                          >
                            <Pencil className="w-5 h-5" />
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          {filteredStudents.length === 0 && (
             <div className="p-12 text-center text-slate-500 flex flex-col items-center">
               <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center mb-3">
                 <Search className="w-6 h-6 text-slate-400" />
               </div>
               <p className="font-medium">No students found</p>
               <p className="text-sm">Try adjusting your search criteria</p>
             </div>
          )}
        </Card>
      </div>
    </DashboardLayout>
  );
};