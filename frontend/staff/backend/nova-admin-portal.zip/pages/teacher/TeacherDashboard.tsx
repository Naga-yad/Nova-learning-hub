import React from 'react';
import { useNavigate } from 'react-router-dom';
import { DashboardLayout } from '../../components/layout/DashboardLayout';
import { UserRole } from '../../types';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Video, CalendarCheck, Megaphone, Trophy, Clock, ArrowRight } from 'lucide-react';

export const TeacherDashboard: React.FC = () => {
  const navigate = useNavigate();

  return (
    <DashboardLayout role={UserRole.TEACHER} title="Teacher Overview">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2 gap-6">
        
        {/* Live Sessions Card */}
        <Card 
          title="Live Sessions" 
          description="Manage your active and upcoming classes"
          icon={<Video className="w-6 h-6 text-emerald-600" />}
          action={
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => navigate('/teacher/sessions')}
            >
              Manage Sessions
            </Button>
          }
        >
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-emerald-50 rounded-lg border border-emerald-100">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></div>
                <div>
                  <p className="text-sm font-semibold text-emerald-900">Advanced Mathematics</p>
                  <p className="text-xs text-emerald-600">Grade 10-A • Live Now</p>
                </div>
              </div>
              <Button size="sm" className="bg-emerald-600 text-white hover:bg-emerald-700" onClick={() => navigate('/teacher/sessions')}>Join</Button>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
              <div className="flex items-center gap-3">
                <Clock className="w-4 h-4 text-slate-400" />
                <div>
                  <p className="text-sm font-medium text-slate-700">Physics Laboratory</p>
                  <p className="text-xs text-slate-500">Today, 2:00 PM</p>
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* Attendance Dashboard */}
        <Card 
          title="Attendance" 
          description="Track student presence and engagement"
          icon={<CalendarCheck className="w-6 h-6 text-emerald-600" />}
        >
           <div className="flex items-end gap-2 mb-4">
             <span className="text-4xl font-bold text-slate-900">94%</span>
             <span className="text-sm text-slate-500 mb-1">Average attendance this week</span>
           </div>
           <div className="w-full bg-slate-100 rounded-full h-2 mb-4">
             <div className="bg-emerald-500 h-2 rounded-full" style={{ width: '94%' }}></div>
           </div>
           <Button variant="outline" fullWidth className="justify-between group">
             View Detailed Report
             <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-slate-600" />
           </Button>
        </Card>

        {/* Announcements & Group Chat */}
        <Card 
          title="Communication" 
          description="Announcements & Class Groups"
          icon={<Megaphone className="w-6 h-6 text-emerald-600" />}
        >
          <div className="space-y-3">
            <div className="p-3 border-l-4 border-emerald-500 bg-slate-50 rounded-r-lg">
              <p className="text-sm font-medium text-slate-900">Mid-term exam schedule released</p>
              <p className="text-xs text-slate-500 mt-1">Sent to: All Students • 2 hrs ago</p>
            </div>
            <div className="p-3 border-l-4 border-amber-500 bg-slate-50 rounded-r-lg">
              <p className="text-sm font-medium text-slate-900">Science Fair project submission</p>
              <p className="text-xs text-slate-500 mt-1">Sent to: Grade 9-B • Yesterday</p>
            </div>
            <Button variant="secondary" fullWidth className="mt-2">Compose Announcement</Button>
          </div>
        </Card>

        {/* Student Marks Management */}
        <Card 
          title="Marks Management" 
          description="Grade assignments and exams"
          icon={<Trophy className="w-6 h-6 text-emerald-600" />}
        >
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div className="p-4 bg-slate-50 rounded-xl text-center hover:bg-slate-100 transition-colors cursor-pointer" onClick={() => navigate('/teacher/marks')}>
              <p className="text-2xl font-bold text-slate-900">12</p>
              <p className="text-xs text-slate-500">Pending Reviews</p>
            </div>
            <div className="p-4 bg-slate-50 rounded-xl text-center hover:bg-slate-100 transition-colors cursor-pointer" onClick={() => navigate('/teacher/marks')}>
              <p className="text-2xl font-bold text-slate-900">28</p>
              <p className="text-xs text-slate-500">Graded Today</p>
            </div>
          </div>
          <Button 
            variant="primary" 
            fullWidth 
            className="bg-emerald-600 hover:bg-emerald-700"
            onClick={() => navigate('/teacher/marks')}
          >
            Open Gradebook
          </Button>
        </Card>
      </div>
    </DashboardLayout>
  );
};