import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { DashboardLayout } from '../../components/layout/DashboardLayout';
import { UserRole } from '../../types';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { 
  Video, 
  Calendar, 
  Clock, 
  Plus, 
  Users, 
  Play, 
  Square, 
  Trash2, 
  ExternalLink,
  MonitorPlay,
  X,
  CheckCircle,
  History
} from 'lucide-react';

interface Session {
  id: string;
  subject: string;
  topic: string;
  grade: string;
  date: string;
  time: string;
  duration: number; // minutes
  status: 'upcoming' | 'live' | 'completed';
  link?: string;
}

const INITIAL_SESSIONS: Session[] = [
  { 
    id: '1', 
    subject: 'Advanced Mathematics', 
    topic: 'Calculus: Derivatives', 
    grade: 'Grade 10-A', 
    date: new Date().toISOString().split('T')[0], 
    time: '10:00', 
    duration: 60, 
    status: 'live',
    link: 'https://meet.google.com/abc-defg-hij'
  },
  { 
    id: '2', 
    subject: 'Physics Laboratory', 
    topic: 'Optics and Light', 
    grade: 'Grade 11-B', 
    date: new Date().toISOString().split('T')[0], 
    time: '14:00', 
    duration: 90, 
    status: 'upcoming',
    link: 'https://meet.google.com/xyz-uvw-rst'
  },
  { 
    id: '3', 
    subject: 'English Literature', 
    topic: 'Shakespeare: Hamlet Analysis', 
    grade: 'Grade 12-A', 
    date: new Date(Date.now() + 86400000).toISOString().split('T')[0], 
    time: '09:00', 
    duration: 45, 
    status: 'upcoming'
  },
  { 
    id: '4', 
    subject: 'History', 
    topic: 'World War II Overview', 
    grade: 'Grade 9-C', 
    date: new Date(Date.now() - 86400000).toISOString().split('T')[0], 
    time: '11:00', 
    duration: 50, 
    status: 'completed'
  },
];

export const LiveSessions: React.FC = () => {
  const navigate = useNavigate();
  const [sessions, setSessions] = useState<Session[]>(INITIAL_SESSIONS);
  const [showForm, setShowForm] = useState(false);
  const [newSession, setNewSession] = useState({
    subject: '',
    topic: '',
    grade: '',
    date: '',
    time: '',
    duration: 60
  });

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    const session: Session = {
      id: Math.random().toString(36).substr(2, 9),
      ...newSession,
      status: 'upcoming',
      link: `https://educore.meet/${Math.random().toString(36).substr(2, 6)}`
    };
    setSessions([...sessions, session]);
    setShowForm(false);
    setNewSession({ subject: '', topic: '', grade: '', date: '', time: '', duration: 60 });
  };

  const deleteSession = (id: string) => {
    if(window.confirm('Are you sure you want to cancel this session?')) {
      setSessions(prev => prev.filter(s => s.id !== id));
    }
  };

  const startSession = (id: string) => {
    setSessions(prev => prev.map(s => s.id === id ? { ...s, status: 'live' } : s));
    navigate(`/teacher/classroom/${id}`);
  };

  const enterClassroom = (id: string) => {
    navigate(`/teacher/classroom/${id}`);
  };

  const endSession = (id: string) => {
    if(window.confirm('End this live session?')) {
      setSessions(prev => prev.map(s => s.id === id ? { ...s, status: 'completed' } : s));
    }
  };

  const liveSessions = sessions.filter(s => s.status === 'live');
  const upcomingSessions = sessions.filter(s => s.status === 'upcoming').sort((a, b) => {
    return new Date(`${a.date}T${a.time}`).getTime() - new Date(`${b.date}T${b.time}`).getTime();
  });
  const completedSessions = sessions.filter(s => s.status === 'completed').sort((a, b) => {
    return new Date(`${b.date}T${b.time}`).getTime() - new Date(`${a.date}T${a.time}`).getTime();
  });

  return (
    <DashboardLayout role={UserRole.TEACHER} title="Live Sessions">
      <div className="space-y-8">
        
        {/* Header Actions */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <p className="text-slate-600">Manage your virtual classroom schedules and active sessions.</p>
          <Button 
            onClick={() => setShowForm(!showForm)} 
            className={`${showForm ? 'bg-slate-100 text-slate-700 hover:bg-slate-200' : 'bg-emerald-600 hover:bg-emerald-700 text-white'}`}
          >
            {showForm ? <><X className="w-4 h-4 mr-2" /> Cancel</> : <><Plus className="w-4 h-4 mr-2" /> Schedule New Session</>}
          </Button>
        </div>

        {/* Create Session Form */}
        {showForm && (
          <Card className="border-emerald-200 shadow-md bg-emerald-50/30">
            <h3 className="text-lg font-semibold text-emerald-900 mb-4 flex items-center gap-2">
              <Calendar className="w-5 h-5" /> Schedule New Class
            </h3>
            <form onSubmit={handleCreate} className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input 
                label="Subject" 
                placeholder="e.g., Mathematics" 
                value={newSession.subject}
                onChange={e => setNewSession({...newSession, subject: e.target.value})}
                required
              />
              <Input 
                label="Topic" 
                placeholder="e.g., Algebra Introduction" 
                value={newSession.topic}
                onChange={e => setNewSession({...newSession, topic: e.target.value})}
                required
              />
              <Input 
                label="Grade/Class" 
                placeholder="e.g., Grade 10-A" 
                value={newSession.grade}
                onChange={e => setNewSession({...newSession, grade: e.target.value})}
                required
              />
              <div className="grid grid-cols-2 gap-4">
                <Input 
                  label="Date" 
                  type="date" 
                  value={newSession.date}
                  onChange={e => setNewSession({...newSession, date: e.target.value})}
                  required
                />
                <Input 
                  label="Time" 
                  type="time" 
                  value={newSession.time}
                  onChange={e => setNewSession({...newSession, time: e.target.value})}
                  required
                />
              </div>
              <div className="md:col-span-2 flex justify-end mt-2">
                <Button type="submit" className="bg-emerald-600 hover:bg-emerald-700">
                  Confirm Schedule
                </Button>
              </div>
            </form>
          </Card>
        )}

        {/* Live Now Section - Red/Emerald Distinct Styling */}
        {liveSessions.length > 0 && (
          <div>
            <div className="flex items-center gap-3 mb-4">
               <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
              </span>
              <h2 className="text-xl font-bold text-slate-900">Live Now</h2>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {liveSessions.map(session => (
                <div key={session.id} className="bg-white rounded-xl shadow-lg border-l-4 border-red-500 overflow-hidden ring-1 ring-slate-100">
                  <div className="p-6">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <span className="inline-block px-2 py-1 bg-red-100 text-red-700 text-xs font-bold rounded mb-2 uppercase tracking-wide">
                          Live Broadcasting
                        </span>
                        <h3 className="text-xl font-bold text-slate-900">{session.subject}</h3>
                        <p className="text-emerald-600 font-medium">{session.topic}</p>
                      </div>
                      <div className="bg-slate-50 p-2 rounded-lg text-center min-w-[80px]">
                        <Users className="w-5 h-5 mx-auto text-slate-500 mb-1" />
                        <span className="text-sm font-bold text-slate-900">24</span>
                        <p className="text-[10px] text-slate-500">Online</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-6 text-sm text-slate-600 mb-6">
                      <div className="flex items-center gap-2">
                        <MonitorPlay className="w-4 h-4" />
                        {session.grade}
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4" />
                        Started at {session.time}
                      </div>
                    </div>

                    <div className="flex gap-3">
                      <Button fullWidth className="bg-emerald-600 hover:bg-emerald-700" onClick={() => enterClassroom(session.id)}>
                        <ExternalLink className="w-4 h-4 mr-2" />
                        Enter Classroom
                      </Button>
                      <Button 
                        variant="danger" 
                        onClick={() => endSession(session.id)}
                        className="bg-red-50 text-red-600 hover:bg-red-100 border-red-100"
                      >
                        <Square className="w-4 h-4 mr-2 fill-current" />
                        End Session
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Schedule & History Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          
          {/* Upcoming Sessions - Indigo Distinct Styling */}
          <div>
            <h2 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-indigo-600" />
              Upcoming Schedule
            </h2>
            {upcomingSessions.length > 0 ? (
              <div className="space-y-4">
                {upcomingSessions.map(session => (
                  <div key={session.id} className="bg-white rounded-xl shadow-sm border border-slate-200 border-l-4 border-l-indigo-500 p-4 hover:shadow-md transition-shadow">
                    <div className="flex justify-between items-start">
                      <div className="flex items-start gap-3">
                        <div className="flex flex-col items-center justify-center w-14 h-14 bg-indigo-50 rounded-lg text-indigo-700 shrink-0">
                          <span className="text-sm font-bold">{session.time}</span>
                        </div>
                        <div>
                          <h4 className="font-semibold text-slate-900">{session.subject}</h4>
                          <p className="text-sm text-slate-500 mb-1">{session.topic}</p>
                          <div className="flex items-center gap-2 text-xs text-slate-500">
                            <span className="font-medium bg-slate-100 px-2 py-0.5 rounded">{session.grade}</span>
                            <span>{session.date}</span>
                            <span>• {session.duration} min</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex flex-col gap-2">
                        <Button 
                          size="sm"
                          onClick={() => startSession(session.id)}
                          className="bg-indigo-600 hover:bg-indigo-700"
                        >
                          <Play className="w-3 h-3 mr-1" /> Start
                        </Button>
                        <button 
                          onClick={() => deleteSession(session.id)}
                          className="text-xs text-red-500 hover:text-red-700 hover:underline text-right"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
               <div className="p-8 text-center text-slate-500 bg-white rounded-xl border border-dashed border-slate-300">
                 <p className="font-medium">No upcoming sessions</p>
               </div>
            )}
          </div>

          {/* Completed Sessions - Gray/Muted Distinct Styling */}
          <div>
            <h2 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-2">
              <History className="w-5 h-5 text-slate-500" />
              Past Sessions
            </h2>
            {completedSessions.length > 0 ? (
              <div className="space-y-4">
                {completedSessions.map(session => (
                  <div key={session.id} className="bg-slate-50 rounded-xl border border-slate-200 border-l-4 border-l-slate-400 p-4 opacity-90 hover:opacity-100 transition-opacity">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-3">
                        <div className="flex items-center justify-center w-10 h-10 bg-slate-200 rounded-full text-slate-500 shrink-0">
                          <CheckCircle className="w-5 h-5" />
                        </div>
                        <div>
                          <h4 className="font-medium text-slate-700">{session.subject}</h4>
                          <p className="text-xs text-slate-500">{session.topic}</p>
                          <p className="text-xs text-slate-400 mt-1">
                            {session.date} • {session.time} • {session.grade}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                         <span className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-slate-200 text-slate-600">
                           Completed
                         </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
               <div className="p-8 text-center text-slate-500 bg-white rounded-xl border border-dashed border-slate-300">
                 <p className="font-medium">No history available</p>
               </div>
            )}
          </div>

        </div>

      </div>
    </DashboardLayout>
  );
};