import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { 
  Mic, MicOff, Video as VideoIcon, VideoOff, 
  MessageSquare, Users, Hand, 
  PhoneOff, Pause, Play, Send, ShieldAlert,
  VolumeX, UserMinus, Bell, Disc,
  AlertTriangle, CheckCircle, Clock, Loader2,
  Camera
} from 'lucide-react';

interface Participant {
  id: string;
  name: string;
  isMuted: boolean;
  isVideoOn: boolean;
  isHandRaised: boolean;
  joinedAt: Date;
  engagementScore: number; // 0-100
}

interface ChatMessage {
  id: string;
  sender: string;
  text: string;
  time: string;
  isAnnouncement?: boolean;
}

export const LiveClassroom: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  
  // Session State
  const [sessionStatus, setSessionStatus] = useState<'live' | 'paused' | 'ended'>('live');
  const [showEndModal, setShowEndModal] = useState(false);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [activeTab, setActiveTab] = useState<'participants' | 'chat'>('participants');
  
  // Media State
  const videoRef = useRef<HTMLVideoElement>(null);
  const [mediaStream, setMediaStream] = useState<MediaStream | null>(null);
  const [micOn, setMicOn] = useState(true);
  const [cameraOn, setCameraOn] = useState(false); // Default to false until permissions granted
  const [isRecording, setIsRecording] = useState(false);
  const [loadingStream, setLoadingStream] = useState(false);
  
  // Content State
  const [newMessage, setNewMessage] = useState('');
  const chatScrollRef = useRef<HTMLDivElement>(null);

  // Mock Data
  const [participants, setParticipants] = useState<Participant[]>([
    { id: '1', name: 'Alice Johnson', isMuted: true, isVideoOn: true, isHandRaised: false, joinedAt: new Date(), engagementScore: 85 },
    { id: '2', name: 'Bob Smith', isMuted: false, isVideoOn: false, isHandRaised: true, joinedAt: new Date(), engagementScore: 60 },
    { id: '3', name: 'Charlie Brown', isMuted: true, isVideoOn: true, isHandRaised: false, joinedAt: new Date(), engagementScore: 92 },
  ]);

  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    { id: '1', sender: 'System', text: 'Session started. Attendance is being tracked.', time: '10:00', isAnnouncement: true },
  ]);

  // --- Media Stream Handling ---

  const startCamera = async () => {
    if (loadingStream) return;
    setLoadingStream(true);
    try {
      // In a real app, you would handle device selection here
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: true 
      });
      
      setMediaStream(stream);
      setCameraOn(true);
      setMicOn(true); // Usually we want mic on when starting call
      
      // Update UI state to reflect successful start
      const msg: ChatMessage = {
        id: Date.now().toString(),
        sender: 'System',
        text: 'Video broadcast started.',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isAnnouncement: true
      };
      setChatMessages(prev => [...prev, msg]);

    } catch (err) {
      console.error("Error accessing media devices:", err);
      alert("Unable to access camera or microphone. Please check your browser permissions.");
      setCameraOn(false);
    } finally {
      setLoadingStream(false);
    }
  };

  const stopCamera = () => {
    if (mediaStream) {
      mediaStream.getTracks().forEach(track => track.stop());
      setMediaStream(null);
    }
    setCameraOn(false);
  };

  // Sync Video Element
  useEffect(() => {
    if (videoRef.current && mediaStream) {
      videoRef.current.srcObject = mediaStream;
    }
  }, [mediaStream]);

  // Handle Stream Tracks based on Session Status and Controls
  useEffect(() => {
    if (mediaStream) {
      // Video track follows session status (freeze on pause)
      mediaStream.getVideoTracks().forEach(track => {
        track.enabled = sessionStatus === 'live';
      });
      
      // Audio track follows session status AND mic toggle
      mediaStream.getAudioTracks().forEach(track => {
        track.enabled = sessionStatus === 'live' && micOn;
      });
    }
  }, [sessionStatus, micOn, mediaStream]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (mediaStream) {
        mediaStream.getTracks().forEach(track => track.stop());
      }
    };
  }, []); // eslint-disable-line

  // --- Handlers ---

  const handleCameraToggle = async () => {
    if (sessionStatus === 'paused') return;
    
    if (cameraOn) {
      stopCamera();
    } else {
      await startCamera();
    }
  };

  const handlePauseToggle = () => {
    const newStatus = sessionStatus === 'live' ? 'paused' : 'live';
    setSessionStatus(newStatus);
    
    // System Message
    const msg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'System',
      text: newStatus === 'paused' ? 'Session paused by teacher. Video broadcast suspended.' : 'Session resumed.',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isAnnouncement: true
    };
    setChatMessages(prev => [...prev, msg]);
  };

  const handleEndSession = () => {
    stopCamera();
    setSessionStatus('ended');
    setShowEndModal(false);
    if (isRecording) setIsRecording(false);
    
    setTimeout(() => {
      navigate('/teacher/sessions');
    }, 4000);
  };

  // --- Other Effects (Timer, Chat, Mock Data) ---

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (sessionStatus !== 'ended') {
      interval = setInterval(() => {
        setElapsedSeconds(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [sessionStatus]);

  const formatTime = (totalSeconds: number) => {
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [chatMessages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || sessionStatus !== 'live') return;
    
    const msg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'You (Teacher)',
      text: newMessage,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isAnnouncement: false
    };
    setChatMessages([...chatMessages, msg]);
    setNewMessage('');
  };

  const postAnnouncement = () => {
    if (!newMessage.trim()) return;
    const msg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'Announcement',
      text: newMessage,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isAnnouncement: true
    };
    setChatMessages([...chatMessages, msg]);
    setNewMessage('');
  };

  const toggleRecording = () => {
    if (sessionStatus !== 'live') return;
    setIsRecording(!isRecording);
    const msg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'System',
      text: !isRecording ? 'Session recording started.' : 'Session recording stopped.',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isAnnouncement: true
    };
    setChatMessages(prev => [...prev, msg]);
  };

  // --- Render ---

  if (sessionStatus === 'ended') {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
        <div className="bg-slate-800 border border-slate-700 rounded-2xl p-8 max-w-md w-full text-center shadow-2xl animate-in zoom-in-95 duration-300">
          <div className="w-16 h-16 bg-emerald-500/10 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-8 h-8 text-emerald-500" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">Session Ended</h2>
          <p className="text-slate-400 mb-8">Class data has been finalized and attendance saved successfully.</p>
          
          <div className="grid grid-cols-2 gap-4 mb-8">
            <div className="bg-slate-700/50 p-4 rounded-xl">
              <p className="text-slate-400 text-xs uppercase font-bold tracking-wider mb-1">Duration</p>
              <p className="text-xl font-mono text-white">{formatTime(elapsedSeconds)}</p>
            </div>
            <div className="bg-slate-700/50 p-4 rounded-xl">
              <p className="text-slate-400 text-xs uppercase font-bold tracking-wider mb-1">Attendance</p>
              <p className="text-xl font-mono text-white">{participants.length} / 25</p>
            </div>
          </div>

          <div className="flex items-center justify-center gap-2 text-sm text-slate-500">
            <Loader2 className="w-4 h-4 animate-spin" />
            Redirecting to dashboard...
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-slate-900 text-white overflow-hidden relative">
      
      {/* End Session Confirmation Modal */}
      {showEndModal && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full shadow-2xl text-slate-900">
            <div className="flex items-start gap-4 mb-4">
              <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center flex-shrink-0">
                <AlertTriangle className="w-5 h-5 text-red-600" />
              </div>
              <div>
                <h3 className="text-lg font-bold">End Session?</h3>
                <p className="text-slate-600 text-sm mt-1">
                  Are you sure you want to end the class? 
                  <ul className="list-disc list-inside mt-2 space-y-1 text-slate-500">
                    <li>Video feed will be terminated for all students.</li>
                    <li>Attendance will be finalized.</li>
                    {isRecording && <li>Recording will be stopped and saved.</li>}
                  </ul>
                </p>
              </div>
            </div>
            <div className="flex gap-3 justify-end mt-6">
              <Button variant="secondary" onClick={() => setShowEndModal(false)}>
                Cancel
              </Button>
              <Button variant="danger" onClick={handleEndSession}>
                End Class
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Top Header */}
      <header className="h-16 bg-slate-800 border-b border-slate-700 flex items-center justify-between px-6 shrink-0 z-10">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3">
            {sessionStatus === 'live' ? (
              <div className="flex items-center gap-2 px-3 py-1 bg-red-500/10 border border-red-500/20 rounded-full">
                <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                <span className="text-xs font-bold text-red-500 uppercase tracking-wide">Live</span>
              </div>
            ) : (
              <div className="flex items-center gap-2 px-3 py-1 bg-amber-500/10 border border-amber-500/20 rounded-full">
                <div className="w-2 h-2 rounded-full bg-amber-500" />
                <span className="text-xs font-bold text-amber-500 uppercase tracking-wide">Paused</span>
              </div>
            )}
            <div className="h-4 w-px bg-slate-700"></div>
            <h1 className="font-bold text-lg hidden md:block">Advanced Mathematics <span className="font-normal text-slate-400">| Grade 10-A</span></h1>
          </div>
          
          <div className="flex items-center gap-4">
             <div className="flex items-center gap-2 text-slate-300 font-mono text-sm bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-700">
              <Clock className="w-3 h-3 text-slate-500" />
              {formatTime(elapsedSeconds)}
            </div>
            {isRecording && (
              <div className="flex items-center gap-1.5 px-2 py-1 bg-red-500/10 rounded text-red-500 text-xs font-bold border border-red-500/20 animate-pulse">
                <div className="w-1.5 h-1.5 rounded-full bg-red-500"></div>
                REC
              </div>
            )}
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <Button 
            size="sm" 
            className={`${sessionStatus === 'paused' ? 'bg-emerald-600 hover:bg-emerald-700 text-white' : 'bg-amber-100 hover:bg-amber-200 text-amber-900 border-amber-200'}`}
            onClick={handlePauseToggle}
          >
            {sessionStatus === 'live' ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
            {sessionStatus === 'live' ? 'Pause' : 'Resume'}
          </Button>
          <Button size="sm" variant="danger" onClick={() => setShowEndModal(true)}>
            <PhoneOff className="w-4 h-4 mr-2" /> End
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex flex-1 overflow-hidden">
        
        {/* Left: Stage/Whiteboard/Video */}
        <div className="flex-1 flex flex-col relative bg-slate-950 p-4">
          
          {/* Main Video Area */}
          <div className="flex-1 bg-slate-900 rounded-2xl border border-slate-800 flex items-center justify-center relative overflow-hidden group shadow-2xl">
            
            {/* PAUSED OVERLAY */}
            {sessionStatus === 'paused' && (
              <div className="absolute inset-0 z-30 bg-slate-900/80 backdrop-blur-md flex flex-col items-center justify-center animate-in fade-in duration-300">
                <div className="w-16 h-16 bg-amber-500 rounded-full flex items-center justify-center mb-4 shadow-lg shadow-amber-900/20">
                  <Pause className="w-8 h-8 text-black fill-current" />
                </div>
                <h2 className="text-2xl font-bold text-white mb-2">Session Paused</h2>
                <p className="text-slate-300">Video broadcast suspended.</p>
                <Button 
                  className="mt-6 bg-white text-slate-900 hover:bg-slate-100"
                  onClick={handlePauseToggle}
                >
                  <Play className="w-4 h-4 mr-2" /> Resume Class
                </Button>
              </div>
            )}

            {/* Video Content */}
            {cameraOn ? (
              <div className="absolute inset-0 bg-black flex items-center justify-center">
                 {/* Live Video Feed */}
                 <video 
                   ref={videoRef}
                   autoPlay
                   muted
                   playsInline
                   className="w-full h-full object-cover transform scale-x-[-1]"
                 />
                 
                 {/* Overlay Elements */}
                 <div className="absolute top-4 right-4 z-10">
                   <div className="bg-black/50 backdrop-blur-sm text-white text-xs px-2 py-1 rounded border border-white/10 flex items-center gap-1.5">
                     <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                     LIVE
                   </div>
                 </div>

                 <div className="absolute bottom-4 left-4 z-10">
                    <p className="text-white text-sm font-medium px-3 py-1.5 bg-black/50 backdrop-blur-sm rounded-lg border border-white/10">
                      You (Teacher)
                    </p>
                 </div>
              </div>
            ) : (
              <div className="absolute inset-0 bg-slate-950 flex flex-col items-center justify-center text-slate-500 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-slate-900 to-slate-950">
                {loadingStream ? (
                  <Loader2 className="w-12 h-12 text-indigo-500 animate-spin mb-4" />
                ) : (
                  <div className="w-24 h-24 bg-slate-900 rounded-full flex items-center justify-center mb-6 border-2 border-slate-800 shadow-xl">
                    <VideoOff className="w-10 h-10 opacity-50" />
                  </div>
                )}
                <p className="font-medium text-lg text-slate-400">{loadingStream ? 'Starting Camera...' : 'Camera is turned off'}</p>
                {!loadingStream && (
                  <Button variant="secondary" className="mt-6" onClick={startCamera}>
                    <Camera className="w-4 h-4 mr-2" /> Start Broadcast
                  </Button>
                )}
              </div>
            )}
            
            {/* Announcement Overlay */}
            {chatMessages.length > 0 && chatMessages[chatMessages.length - 1].isAnnouncement && (
              <div className="absolute top-6 left-1/2 -translate-x-1/2 z-20 bg-amber-500/90 text-white px-6 py-2 rounded-full shadow-lg flex items-center gap-2 animate-in fade-in slide-in-from-top-4 max-w-lg truncate">
                <Bell className="w-4 h-4 flex-shrink-0" />
                <span className="text-sm font-medium">{chatMessages[chatMessages.length - 1].text}</span>
              </div>
            )}

            {/* Hand Raised Notification */}
            {participants.some(p => p.isHandRaised) && (
              <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-20 bg-slate-800/90 border border-slate-700 text-white px-4 py-3 rounded-lg shadow-lg flex items-center gap-3 animate-bounce-in">
                <div className="bg-yellow-500 p-1.5 rounded-full text-black"><Hand className="w-4 h-4" /></div>
                <div>
                  <p className="text-sm font-bold">{participants.filter(p => p.isHandRaised).length} Hand(s) Raised</p>
                </div>
              </div>
            )}
          </div>

          {/* Teacher Controls Toolbar */}
          <div className="h-20 mt-4 flex justify-center items-center gap-4 bg-slate-900/50 rounded-2xl border border-slate-800/50 backdrop-blur-sm">
             <button 
               onClick={() => setMicOn(!micOn)}
               className={`p-4 rounded-full transition-all duration-200 shadow-lg ${micOn ? 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-700' : 'bg-red-500 hover:bg-red-600 text-white border border-red-400'}`}
               title={micOn ? "Turn Off Microphone" : "Turn On Microphone"}
               disabled={sessionStatus === 'paused'}
             >
               {micOn ? <Mic className="w-6 h-6" /> : <MicOff className="w-6 h-6" />}
             </button>
             <button 
               onClick={handleCameraToggle}
               className={`p-4 rounded-full transition-all duration-200 shadow-lg ${cameraOn ? 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-700' : 'bg-red-500 hover:bg-red-600 text-white border border-red-400'}`}
               title={cameraOn ? "Turn Off Camera" : "Turn On Camera"}
               disabled={sessionStatus === 'paused' || loadingStream}
             >
               {cameraOn ? <VideoIcon className="w-6 h-6" /> : <VideoOff className="w-6 h-6" />}
             </button>
             
             <div className="w-px h-8 bg-slate-700 mx-2"></div>
             
             <button 
                onClick={toggleRecording}
                className={`p-4 rounded-full transition-all duration-200 shadow-lg ${isRecording ? 'bg-red-500 hover:bg-red-600 text-white animate-pulse' : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'}`}
                title={isRecording ? "Stop Recording" : "Start Recording"}
                disabled={sessionStatus === 'paused'}
             >
               <Disc className={`w-6 h-6`} />
             </button>

             <button 
                onClick={() => setParticipants(prev => prev.map(p => ({ ...p, isMuted: true })))}
                className="p-4 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-all duration-200 border border-slate-700 shadow-lg"
                title="Mute All Students"
                disabled={sessionStatus === 'paused'}
             >
               <VolumeX className="w-6 h-6" />
             </button>
          </div>
        </div>

        {/* Right: Sidebar */}
        <div className="w-80 bg-slate-900 border-l border-slate-800 flex flex-col shrink-0">
          {/* Tabs */}
          <div className="flex border-b border-slate-800">
            <button 
              onClick={() => setActiveTab('participants')}
              className={`flex-1 py-4 text-sm font-medium flex items-center justify-center gap-2 transition-colors ${activeTab === 'participants' ? 'text-indigo-400 border-b-2 border-indigo-500 bg-indigo-500/5' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'}`}
            >
              <Users className="w-4 h-4" />
              People ({participants.length})
            </button>
            <button 
              onClick={() => setActiveTab('chat')}
              className={`flex-1 py-4 text-sm font-medium flex items-center justify-center gap-2 transition-colors ${activeTab === 'chat' ? 'text-indigo-400 border-b-2 border-indigo-500 bg-indigo-500/5' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'}`}
            >
              <MessageSquare className="w-4 h-4" />
              Chat
            </button>
          </div>

          {/* Sidebar Content */}
          <div className="flex-1 overflow-hidden flex flex-col bg-slate-900">
            
            {activeTab === 'participants' && (
              <div className="flex-1 overflow-y-auto p-4 space-y-4">
                <div className="flex justify-between items-center text-xs text-slate-500 uppercase font-semibold">
                  <span>Student List</span>
                  <span>Attd: {Math.round((participants.length / 25) * 100)}%</span>
                </div>
                
                {participants.map(p => (
                  <div key={p.id} className="flex items-center justify-between p-3 rounded-lg bg-slate-800/50 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 transition-colors group">
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <div className="w-8 h-8 rounded-full bg-indigo-900/50 flex items-center justify-center text-xs font-bold text-indigo-300 border border-indigo-500/20 overflow-hidden">
                           {/* Fallback avatar or mock video thumb */}
                           {p.name.charAt(0)}
                        </div>
                        {p.isHandRaised && (
                          <div className="absolute -top-1 -right-1 bg-yellow-500 rounded-full p-0.5 shadow-sm animate-pulse">
                            <Hand className="w-2 h-2 text-black" />
                          </div>
                        )}
                      </div>
                      <div>
                        <p className="text-sm font-medium text-slate-200 leading-tight">{p.name}</p>
                        <div className="flex items-center gap-2 mt-1">
                           {/* Engagement Bar */}
                           <div className="w-12 h-1 bg-slate-700 rounded-full overflow-hidden" title={`Engagement Score: ${p.engagementScore}%`}>
                             <div 
                                className={`h-full rounded-full ${p.engagementScore > 70 ? 'bg-emerald-500' : p.engagementScore > 40 ? 'bg-yellow-500' : 'bg-red-500'}`} 
                                style={{ width: `${p.engagementScore}%` }}
                             ></div>
                           </div>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 opacity-60 group-hover:opacity-100 transition-opacity">
                      {p.isHandRaised && (
                         <button onClick={() => setParticipants(prev => prev.map(pt => pt.id === p.id ? { ...pt, isHandRaised: false } : pt))} className="p-1.5 text-yellow-500 hover:bg-yellow-500/10 rounded" title="Lower Hand">
                           <Hand className="w-3 h-3" />
                         </button>
                      )}
                      <button className={`p-1.5 rounded cursor-default ${p.isMuted ? 'text-red-400' : 'text-emerald-400'}`}>
                        {p.isMuted ? <MicOff className="w-3 h-3" /> : <Mic className="w-3 h-3" />}
                      </button>
                      <button onClick={() => { if(confirm('Remove student?')) setParticipants(prev => prev.filter(pt => pt.id !== p.id)) }} className="p-1.5 text-slate-500 hover:text-red-500 hover:bg-red-500/10 rounded" title="Remove Student">
                        <UserMinus className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {activeTab === 'chat' && (
              <>
                <div ref={chatScrollRef} className="flex-1 overflow-y-auto p-4 space-y-3 scroll-smooth">
                  {chatMessages.map(msg => (
                    <div key={msg.id} className={`flex flex-col ${msg.sender === 'You (Teacher)' ? 'items-end' : 'items-start'}`}>
                      {msg.isAnnouncement ? (
                         <div className="w-full bg-slate-800/50 border border-slate-700 rounded-lg p-2 text-center my-2">
                           <p className="text-[10px] text-slate-400 font-bold uppercase mb-1 tracking-wider">{msg.sender}</p>
                           <p className="text-sm text-slate-300">{msg.text}</p>
                         </div>
                      ) : (
                        <>
                          <div className="flex items-baseline gap-2 mb-1 px-1">
                            <span className="text-xs font-bold text-slate-400">{msg.sender}</span>
                            <span className="text-[10px] text-slate-600">{msg.time}</span>
                          </div>
                          <div className={`px-3 py-2 rounded-2xl text-sm max-w-[85%] ${msg.sender === 'You (Teacher)' ? 'bg-indigo-600 text-white rounded-tr-sm' : 'bg-slate-800 text-slate-200 rounded-tl-sm'}`}>
                            {msg.text}
                          </div>
                        </>
                      )}
                    </div>
                  ))}
                </div>
                <div className="p-4 bg-slate-800/80 border-t border-slate-700 backdrop-blur-sm">
                  {sessionStatus === 'live' ? (
                    <>
                      <form onSubmit={handleSendMessage} className="flex gap-2 mb-2">
                        <Input 
                          placeholder="Type a message..." 
                          className="bg-slate-900 border-slate-700 text-white placeholder-slate-500 focus:ring-indigo-500 rounded-full px-4"
                          value={newMessage}
                          onChange={e => setNewMessage(e.target.value)}
                        />
                        <Button type="submit" size="sm" className="bg-indigo-600 hover:bg-indigo-700 px-3 rounded-full w-10 h-10 p-0 flex items-center justify-center shrink-0">
                          <Send className="w-4 h-4 ml-0.5" />
                        </Button>
                      </form>
                      <button 
                        type="button"
                        onClick={postAnnouncement}
                        className="text-xs text-amber-500 hover:text-amber-400 flex items-center gap-1 w-full justify-center py-1 hover:bg-amber-500/5 rounded transition-colors"
                      >
                        <ShieldAlert className="w-3 h-3" /> Post as Announcement
                      </button>
                    </>
                  ) : (
                    <div className="py-4 text-center">
                        <p className="text-sm text-amber-500 flex items-center justify-center gap-2">
                            <Pause className="w-4 h-4" /> Chat paused
                        </p>
                    </div>
                  )}
                </div>
              </>
            )}

          </div>
        </div>
      </div>
    </div>
  );
};