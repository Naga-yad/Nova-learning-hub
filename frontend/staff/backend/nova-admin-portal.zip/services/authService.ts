import { User, UserRole, LoginCredentials, SignupCredentials } from '../types';

// Mock API delay
const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

export const authService = {
  login: async (credentials: LoginCredentials, role: UserRole): Promise<User> => {
    await delay(800); // Simulate network request

    // In a real app, this would hit a Django JWT endpoint
    // e.g., axios.post('/api/token/', { ...credentials })

    // Simulating validation
    if (!credentials.username || !credentials.password) {
      throw new Error('Invalid credentials');
    }

    // Return a mock user
    return {
      id: '12345',
      name: role === UserRole.ADMIN ? 'Admin User' : 'Teacher User',
      email: `${credentials.username}@nova.com`,
      role: role,
      token: 'mock-jwt-token-xyz-123',
      avatarUrl: `https://picsum.photos/seed/${role}/200`,
    };
  },

  signup: async (data: SignupCredentials, role: UserRole): Promise<User> => {
    await delay(1000); // Simulate network request
    
    // In a real app, this would handle FormData for file upload
    
    return {
      id: Math.random().toString(36).substr(2, 9),
      name: data.name,
      email: data.email,
      role: role,
      token: 'mock-jwt-token-new-user',
      avatarUrl: data.photo ? URL.createObjectURL(data.photo) : undefined,
    };
  }
};