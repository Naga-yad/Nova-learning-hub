import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { Welcome } from './pages/Welcome';
import { SignIn } from './pages/auth/SignIn';
import { SignUp } from './pages/auth/SignUp';
import { TeacherDashboard } from './pages/teacher/TeacherDashboard';
import { MarksManagement } from './pages/teacher/MarksManagement';
import { LiveSessions } from './pages/teacher/LiveSessions';
import { LiveClassroom } from './pages/teacher/LiveClassroom';
import { AdminDashboard } from './pages/admin/AdminDashboard';
import { TeacherManagement } from './pages/admin/TeacherManagement';
import { StudentManagement } from './pages/admin/StudentManagement';
import { Scheduler } from './pages/admin/Scheduler';
import { ProtectedRoute } from './routes/ProtectedRoute';
import { UserRole } from './types';

const App: React.FC = () => {
  return (
    <AuthProvider>
      <HashRouter>
        <Routes>
          <Route path="/" element={<Welcome />} />
          
          {/* Teacher Routes */}
          <Route path="/teacher/login" element={<SignIn role={UserRole.TEACHER} />} />
          <Route path="/teacher/signup" element={<SignUp role={UserRole.TEACHER} />} />
          <Route 
            path="/teacher/dashboard" 
            element={
              <ProtectedRoute allowedRole={UserRole.TEACHER}>
                <TeacherDashboard />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/teacher/marks" 
            element={
              <ProtectedRoute allowedRole={UserRole.TEACHER}>
                <MarksManagement />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/teacher/sessions" 
            element={
              <ProtectedRoute allowedRole={UserRole.TEACHER}>
                <LiveSessions />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/teacher/classroom/:id" 
            element={
              <ProtectedRoute allowedRole={UserRole.TEACHER}>
                <LiveClassroom />
              </ProtectedRoute>
            } 
          />

          {/* Admin Routes */}
          <Route path="/admin/login" element={<SignIn role={UserRole.ADMIN} />} />
          <Route path="/admin/signup" element={<SignUp role={UserRole.ADMIN} />} />
          <Route 
            path="/admin/dashboard" 
            element={
              <ProtectedRoute allowedRole={UserRole.ADMIN}>
                <AdminDashboard />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/admin/teachers" 
            element={
              <ProtectedRoute allowedRole={UserRole.ADMIN}>
                <TeacherManagement />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/admin/students" 
            element={
              <ProtectedRoute allowedRole={UserRole.ADMIN}>
                <StudentManagement />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/admin/scheduler" 
            element={
              <ProtectedRoute allowedRole={UserRole.ADMIN}>
                <Scheduler />
              </ProtectedRoute>
            } 
          />

          {/* Catch all - redirect to Welcome */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </HashRouter>
    </AuthProvider>
  );
};

export default App;